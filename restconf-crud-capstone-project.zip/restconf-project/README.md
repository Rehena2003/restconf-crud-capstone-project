# Secure RESTCONF-Based Network Management System (NMS)

This project is a Wipro training capstone project implementing a **Secure RESTCONF-Based Network Management System** built with Java 17, Spring Boot, Spring Security, JWT authentication, Spring Data JPA, and MySQL.

---

## 🏗️ Architecture & Component Flow

The system employs a standard **layered architecture** to keep the codebase simple, readable, and presentation-friendly for fresher-level developer interviews.

1. **Client Layer (`RestconfClient`)**: Standalone Java console program mimicking client-side RESTCONF CRUD configuration interactions with the server using Java `HttpURLConnection`.
2. **Controller Layer**: REST APIs exposing endpoints for authentication (`/api/auth/login`), network resource management (`/restconf/config`), and auditing logs (`/api/audit-logs`).
3. **Security Layer (Spring Security + JWT)**: Intercepts requests, validates JWT Bearer tokens, and authorizes user operations based on roles.
4. **Service Layer**: Implements business rules for authentication and configuration CRUD while triggering audit logging.
5. **Repository Layer**: Utilizes Spring Data JPA interfaces for DB query definitions.
6. **Entity Layer**: Defines database tables for `User`, `NetworkConfig` (status: `ACTIVE`/`INACTIVE`), and `AuditLog`.

---

## 🔐 Role-Based Access Control (RBAC) Matrix

Users are pre-saved into the database on startup (`CommandLineRunner`):

| Username | Password | Role | Permitted Actions |
| :--- | :--- | :--- | :--- |
| **admin** | `adminpassword` | **ADMIN** | Full RESTCONF CRUD operations + View Audit Logs |
| **operator** | `operatorpassword` | **OPERATOR** | Create, Read, and Update Network Configs (No Delete, No Audit Logs) |
| **viewer** | `viewerpassword` | **VIEWER** | Read-Only Network Configs (No Create, Update, Delete, or Audit Logs) |

---

## 🚀 Running the Project

### Prerequisites
1. **Java 17** or higher installed.
2. **MySQL Server** running at `localhost:3306`.
3. MySQL credentials: username: `root`, password: `root` (you can change this in `src/main/resources/application.properties`).
4. A database named `restconf_db` (the application creates it automatically if it doesn't exist).

### Step 1: Start the RESTCONF Server
In your terminal, navigate to the root directory and execute:
```bash
mvn spring-boot:run
```
The server will start at `http://localhost:8080` and initialize the default database tables and default credentials in MySQL automatically.

### Step 2: Access Swagger/OpenAPI Documentation
Open your web browser and navigate to:
```
http://localhost:8080/swagger-ui/index.html
```
- Use the `/api/auth/login` endpoint with user details to fetch a JWT token.
- Click **Authorize** (top right) and paste the token to test other role-restricted endpoints directly in the UI!

### Step 3: Run the Java HTTP Client Demo
In a separate terminal, execute the following command:
```bash
mvn exec:java -Dexec.mainClass="com.example.client.RestconfClient"
```
The console will output the flow of the client:
- Logging in as `admin`, retrieving JWT token.
- Executing CREATE, GET, UPDATE, and GET ALL configuration requests.
- Logging in as `viewer`, retrieving JWT token.
- Attempting GET (allowed) and POST (blocked with `403 Forbidden` response code).
- Logging in as `admin` to delete the config resource.

---

## 📁 Project Structure

```
secure-restconf-nms/
│
├── src/main/java/com/example/
│   ├── restconf/                      # Server Code Base
│   │   ├── RestconfApplication.java   # Spring Boot Main Application
│   │   ├── config/                    # Security, OpenAPI & DataInitializer Configuration
│   │   ├── controller/                # Rest Controllers (Auth, Config, AuditLog)
│   │   ├── dto/                       # Request/Response payloads
│   │   ├── entity/                    # JPA Models (User, Role, NetworkConfig, AuditLog)
│   │   ├── repository/                # Data JPA query Interfaces
│   │   ├── security/                  # JWT security beans & custom user details
│   │   └── service/                   # Core business services & audit trail logging
│   │
│   └── client/
│       └── RestconfClient.java        # Simulated RESTCONF Java HTTP Client
│
├── src/main/resources/
│   └── application.properties         # Properties (MySQL details & JWT secret key)
│
├── postman/
│   └── restconf-project.postman_collection.json  # Postman test collection
│
└── README.md                          # Technical execution guide
```

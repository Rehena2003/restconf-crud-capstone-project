// Check if token already exists, redirect immediately
if (localStorage.getItem("token")) {
    window.location.href = "/dashboard";
}

document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    const usernameInput = document.getElementById("username").value.trim();
    const passwordInput = document.getElementById("password").value;
    const errorAlert = document.getElementById("errorAlert");
    const submitBtn = document.getElementById("submitBtn");

    errorAlert.style.display = "none";
    submitBtn.disabled = true;
    submitBtn.textContent = "Signing In...";

    fetch("/api/auth/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            username: usernameInput,
            password: passwordInput
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Authentication failed");
        }
        return response.json();
    })
    .then(data => {
        // Save JWT, username, and role to localStorage
        localStorage.setItem("token", data.token);
        localStorage.setItem("username", data.username);
        localStorage.setItem("role", data.role);
        
        // Redirect to dashboard
        window.location.href = "/dashboard";
    })
    .catch(error => {
        console.error("Login Error:", error);
        errorAlert.style.display = "block";
        submitBtn.disabled = false;
        submitBtn.textContent = "Sign In";
    });
});

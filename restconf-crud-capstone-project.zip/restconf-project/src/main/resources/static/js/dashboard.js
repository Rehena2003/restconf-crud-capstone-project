// Redirect to login if token is missing
const token = localStorage.getItem("token");
const username = localStorage.getItem("username");
const role = localStorage.getItem("role");

if (!token) {
    window.location.href = "/login";
}

// Initialize UI display with profile details
document.getElementById("welcomeUser").textContent = `Welcome, ${username || 'User'}`;
document.getElementById("userProfileName").textContent = username || 'user';

const roleBadge = document.getElementById("userProfileRole");
roleBadge.textContent = role || 'VIEWER';
roleBadge.className = 'badge-role';
if (role === 'ADMIN') roleBadge.classList.add('role-admin');
else if (role === 'OPERATOR') roleBadge.classList.add('role-operator');
else roleBadge.classList.add('role-viewer');

// Apply Role-Based Access Controls
if (role === 'ADMIN') {
    document.getElementById("auditLogsNav").classList.remove("d-none");
    document.getElementById("addDeviceBtn").classList.remove("d-none");
} else if (role === 'OPERATOR') {
    document.getElementById("addDeviceBtn").classList.remove("d-none");
} else {
    // VIEWER role
    document.getElementById("opsStatCard").classList.add("d-none");
}

// Panel Switcher
function switchPanel(panelId, btnElement) {
    // Hide all panels
    document.querySelectorAll(".content-panel").forEach(panel => {
        panel.classList.remove("active");
    });
    // Show target panel
    document.getElementById(panelId).classList.add("active");

    // Deactivate all nav buttons
    document.querySelectorAll(".nav-item-btn").forEach(btn => {
        btn.classList.remove("active");
    });
    // Activate current button
    if (btnElement) {
        btnElement.classList.add("active");
    }

    // Reload data for target panels
    if (panelId === 'devices-panel') {
        loadDevices();
    } else if (panelId === 'logs-panel') {
        loadLogs();
    } else if (panelId === 'dashboard-panel') {
        loadDashboardStats();
    }
}

// Fetch headers helper
function getHeaders() {
    return {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
    };
}

// Global Data Cache for Stats calculation
let allDevices = [];

// Load Dashboard stats counters & mini chart height
function loadDashboardStats() {
    fetch("/restconf/config", {
        method: "GET",
        headers: getHeaders()
    })
    .then(res => {
        if (res.status === 401) { logout(); }
        return res.json();
    })
    .then(data => {
        allDevices = data;
        const total = data.length;
        const active = data.filter(d => d.status === 'ACTIVE').length;
        const inactive = total - active;

        // Animate/populate counters
        document.getElementById("countTotal").textContent = total;
        document.getElementById("countOnline").textContent = active;
        document.getElementById("countOffline").textContent = inactive;

        document.getElementById("lblTotal").textContent = total;
        document.getElementById("lblOnline").textContent = active;
        document.getElementById("lblOffline").textContent = inactive;

        // Animate HTML bar heights
        const maxVal = Math.max(total, 1);
        document.getElementById("barTotal").style.height = `${(total / maxVal) * 90}px`;
        document.getElementById("barOnline").style.height = `${(active / maxVal) * 90}px`;
        document.getElementById("barOffline").style.height = `${(inactive / maxVal) * 90}px`;

        // Load Ops count if Admin
        if (role === 'ADMIN') {
            fetch("/api/audit-logs", {
                method: "GET",
                headers: getHeaders()
            })
            .then(res => res.json())
            .then(logs => {
                document.getElementById("countOps").textContent = logs.length;
            })
            .catch(err => console.error("Logs Fetch Error", err));
        }
    })
    .catch(err => console.error("Error loading stats", err));
}

// Load Devices Table
function loadDevices() {
    const tableBody = document.getElementById("devicesTableBody");
    tableBody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">Loading configurations...</td></tr>`;

    fetch("/restconf/config", {
        method: "GET",
        headers: getHeaders()
    })
    .then(res => res.json())
    .then(data => {
        tableBody.innerHTML = "";
        if (data.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">No configurations found. Add a device to get started.</td></tr>`;
            return;
        }

        data.forEach(device => {
            const row = document.createElement("tr");

            // Status column formatting
            const statusClass = device.status === 'ACTIVE' ? 'status-on' : 'status-off';

            // Date parsing
            let dateStr = "N/A";
            if (device.updatedAt) {
                try {
                    const dateObj = new Date(device.updatedAt);
                    dateStr = dateObj.toLocaleDateString() + ' ' + dateObj.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                } catch(e) {
                    dateStr = device.updatedAt;
                }
            }

            // Render action buttons based on user roles
            let actionsHtml = "";
            if (role === 'ADMIN') {
                actionsHtml = `
                    <button class="btn btn-sm btn-outline-warning me-1" onclick="openEditModal('${device.id}', '${device.hostname}', '${device.ipAddress}', '${device.status}')"><i class="bi bi-pencil"></i></button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteDevice('${device.id}')"><i class="bi bi-trash"></i></button>
                `;
            } else if (role === 'OPERATOR') {
                actionsHtml = `
                    <button class="btn btn-sm btn-outline-warning" onclick="openEditModal('${device.id}', '${device.hostname}', '${device.ipAddress}', '${device.status}')"><i class="bi bi-pencil"></i></button>
                `;
            } else {
                actionsHtml = `<span class="text-muted small">Read-Only</span>`;
            }

            // If viewer, hide the actions header column text and center text
            if (role === 'VIEWER') {
                document.getElementById("actionsHeader").style.display = "none";
                row.innerHTML = `
                    <td><strong>${device.id}</strong></td>
                    <td>${device.hostname}</td>
                    <td><code>${device.ipAddress}</code></td>
                    <td><span class="badge-status ${statusClass}">${device.status}</span></td>
                    <td>${dateStr}</td>
                `;
            } else {
                document.getElementById("actionsHeader").style.display = "table-cell";
                row.innerHTML = `
                    <td><strong>${device.id}</strong></td>
                    <td>${device.hostname}</td>
                    <td><code>${device.ipAddress}</code></td>
                    <td><span class="badge-status ${statusClass}">${device.status}</span></td>
                    <td>${dateStr}</td>
                    <td class="text-end">${actionsHtml}</td>
                `;
            }

            tableBody.appendChild(row);
        });
    })
    .catch(err => {
        tableBody.innerHTML = `<tr><td colspan="6" class="text-center text-danger py-4">Error loading data. Make sure token is valid.</td></tr>`;
    });
}

// Load Audit Logs Table
function loadLogs() {
    if (role !== 'ADMIN') return;
    const tableBody = document.getElementById("logsTableBody");
    tableBody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">Loading audit logs...</td></tr>`;

    fetch("/api/audit-logs", {
        method: "GET",
        headers: getHeaders()
    })
    .then(res => res.json())
    .then(data => {
        tableBody.innerHTML = "";
        if (data.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">No audit logs available.</td></tr>`;
            return;
        }

        data.forEach(log => {
            const row = document.createElement("tr");

            let dateStr = log.timestamp;
            if (log.timestamp) {
                try {
                    const dateObj = new Date(log.timestamp);
                    dateStr = dateObj.toLocaleDateString() + ' ' + dateObj.toLocaleTimeString();
                } catch(e) {}
            }

            let opClass = "op-read";
            if (log.operation === 'CREATE') opClass = 'op-create';
            else if (log.operation === 'UPDATE') opClass = 'op-update';
            else if (log.operation === 'DELETE') opClass = 'op-delete';

            row.innerHTML = `
                <td><small class="text-muted">${log.id}</small></td>
                <td><span class="op-badge ${opClass}">${log.operation}</span></td>
                <td>${log.entityType}</td>
                <td><strong>${log.username}</strong></td>
                <td><small>${dateStr}</small></td>
                <td class="text-muted small">${log.details}</td>
            `;
            tableBody.appendChild(row);
        });
    })
    .catch(err => {
        tableBody.innerHTML = `<tr><td colspan="6" class="text-center text-danger py-4">Error fetching logs. Check server state.</td></tr>`;
    });
}

// CRUD Modals and form hooks
let deviceBsModal;
document.addEventListener("DOMContentLoaded", () => {
    deviceBsModal = new bootstrap.Modal(document.getElementById('deviceModal'));
    loadDashboardStats();
});

function openAddModal() {
    document.getElementById("deviceModalTitle").textContent = "Add Network Device";
    document.getElementById("editOriginalId").value = "";
    document.getElementById("deviceId").value = "";
    document.getElementById("deviceId").disabled = false;
    document.getElementById("deviceHostname").value = "";
    document.getElementById("deviceIp").value = "";
    document.getElementById("deviceStatus").value = "ACTIVE";

    deviceBsModal.show();
}

function openEditModal(id, hostname, ip, status) {
    document.getElementById("deviceModalTitle").textContent = "Edit Network Device";
    document.getElementById("editOriginalId").value = id;
    document.getElementById("deviceId").value = id;
    document.getElementById("deviceId").disabled = true; // Primary Key cannot change
    document.getElementById("deviceHostname").value = hostname;
    document.getElementById("deviceIp").value = ip;
    document.getElementById("deviceStatus").value = status;

    deviceBsModal.show();
}

document.getElementById("deviceForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const originalId = document.getElementById("editOriginalId").value;
    const id = document.getElementById("deviceId").value.trim();
    const hostname = document.getElementById("deviceHostname").value.trim();
    const ipAddress = document.getElementById("deviceIp").value.trim();
    const status = document.getElementById("deviceStatus").value;

    const isEdit = originalId !== "";
    const url = isEdit ? `/restconf/config/${originalId}` : "/restconf/config";
    const method = isEdit ? "PUT" : "POST";

    const payload = { id, hostname, ipAddress, status };

    fetch(url, {
        method: method,
        headers: getHeaders(),
        body: JSON.stringify(payload)
    })
    .then(res => {
        if (!res.ok) throw new Error("Operation failed");
        return res.json();
    })
    .then(() => {
        deviceBsModal.hide();
        loadDevices();
        loadDashboardStats();
    })
    .catch(err => {
        alert("Error saving configuration! Make sure IP details are valid and role authorized.");
    });
});

// Delete device operation
function deleteDevice(id) {
    if (!confirm(`Are you sure you want to delete configuration resource ${id}?`)) {
        return;
    }

    fetch(`/restconf/config/${id}`, {
        method: "DELETE",
        headers: getHeaders()
    })
    .then(res => {
        if (!res.ok) throw new Error("Delete failed");
        loadDevices();
        loadDashboardStats();
    })
    .catch(err => {
        alert("Delete failed! User is likely unauthorized.");
    });
}

// Logout execution
function logout() {
    localStorage.clear();
    window.location.href = "/login";
}

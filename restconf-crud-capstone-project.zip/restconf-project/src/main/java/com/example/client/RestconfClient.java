package com.example.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class RestconfClient {

    private static final String BASE_URL = "http://localhost:8080/restconf/config";
    private static final String LOGIN_URL = "http://localhost:8080/api/auth/login";

    public static void main(String[] args) {
        try {
            System.out.println("=== PART 1: LOGGING IN AS ADMIN AND RUNNING SUCCESSFUL CRUD ===");
            String adminToken = getJwtToken("admin", "adminpassword");
            if (adminToken == null) {
                System.err.println("Admin login failed!");
                return;
            }
            System.out.println("Admin JWT Token retrieved successfully!");

            // 1. CREATE config
            String jsonCreate = "{\"id\":\"1\",\"hostname\":\"Router-HQ\",\"ipAddress\":\"10.0.0.1\",\"status\":\"ACTIVE\"}";
            sendRequest("POST", BASE_URL, jsonCreate, adminToken);

            // 2. GET config
            sendRequest("GET", BASE_URL + "/1", null, adminToken);

            // 3. UPDATE config
            String jsonUpdate = "{\"id\":\"1\",\"hostname\":\"Router-HQ-Updated\",\"ipAddress\":\"10.0.0.254\",\"status\":\"ACTIVE\"}";
            sendRequest("PUT", BASE_URL + "/1", jsonUpdate, adminToken);

            // 4. GET ALL configs to see update
            sendRequest("GET", BASE_URL, null, adminToken);


            System.out.println("\n=== PART 2: LOGGING IN AS VIEWER TO TEST ACCESS CONTROL ===");
            String viewerToken = getJwtToken("viewer", "viewerpassword");
            if (viewerToken == null) {
                System.err.println("Viewer login failed!");
                return;
            }
            System.out.println("Viewer JWT Token retrieved successfully!");

            // 1. GET config as Viewer (Allowed - 200 OK)
            sendRequest("GET", BASE_URL + "/1", null, viewerToken);

            // 2. Try to CREATE config as Viewer (Denied - 403 Forbidden)
            String jsonViewerCreate = "{\"id\":\"2\",\"hostname\":\"Switch-Branch\",\"ipAddress\":\"192.168.2.1\",\"status\":\"ACTIVE\"}";
            System.out.println("\nAttempting to CREATE as VIEWER (expecting 403 Forbidden):");
            sendRequest("POST", BASE_URL, jsonViewerCreate, viewerToken);


            System.out.println("\n=== PART 3: CLEANING UP DATABASE USING ADMIN ===");
            // DELETE config as ADMIN (Allowed - 200 OK)
            sendRequest("DELETE", BASE_URL + "/1", null, adminToken);

            // Confirm delete
            sendRequest("GET", BASE_URL + "/1", null, adminToken);

            System.out.println("\n=== PART 4: FETCHING AUDIT LOGS FROM DATABASE (ADMIN ONLY) ===");
            sendRequest("GET", "http://localhost:8080/api/audit-logs", null, adminToken);

            System.out.println("\nRESTCONF Client execution completed successfully!");

        } catch (Exception e) {
            System.err.println("Error executing RestconfClient: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static String getJwtToken(String username, String password) throws Exception {
        URL url = new URL(LOGIN_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        String loginPayload = "{\"username\":\"" + username + "\",\"password\":\"" + password + "\"}";
        OutputStream os = conn.getOutputStream();
        os.write(loginPayload.getBytes());
        os.flush();
        os.close();

        int responseCode = conn.getResponseCode();
        if (responseCode == 200) {
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // Simple string parsing to extract JWT token from JSON {"token":"..."}
            String respStr = response.toString();
            int start = respStr.indexOf("\"token\":\"") + 9;
            int end = respStr.indexOf("\"", start);
            return respStr.substring(start, end);
        } else {
            System.err.println("Login HTTP Error Code: " + responseCode);
            return null;
        }
    }

    private static void sendRequest(String method, String urlStr, String body, String jwtToken) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod(method);
            conn.setRequestProperty("Content-Type", "application/json");
            
            if (jwtToken != null) {
                conn.setRequestProperty("Authorization", "Bearer " + jwtToken);
            }

            if (body != null) {
                conn.setDoOutput(true);
                OutputStream os = conn.getOutputStream();
                os.write(body.getBytes());
                os.flush();
                os.close();
            }

            int responseCode = conn.getResponseCode();
            System.out.println(method + " " + urlStr + " -> Response Code: " + responseCode);

            // Read response
            BufferedReader in;
            if (responseCode >= 200 && responseCode < 300) {
                in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            } else {
                in = new BufferedReader(new InputStreamReader(conn.getErrorStream() != null ? conn.getErrorStream() : conn.getInputStream()));
            }

            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            
            if (response.length() > 0) {
                System.out.println("Response Body: " + response.toString());
            }

        } catch (Exception e) {
            System.err.println("Error sending " + method + " request: " + e.getMessage());
        }
    }
}

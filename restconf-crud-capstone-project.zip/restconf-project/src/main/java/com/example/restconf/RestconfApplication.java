package com.example.restconf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestconfApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestconfApplication.class, args);
    }
}

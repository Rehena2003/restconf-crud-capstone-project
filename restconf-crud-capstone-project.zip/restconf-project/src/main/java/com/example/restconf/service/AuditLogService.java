package com.example.restconf.service;

import com.example.restconf.entity.AuditLog;
import com.example.restconf.repository.AuditLogRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public AuditLogService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public void log(String operation, String entityType, String details) {
        String username = "SYSTEM";
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated() && !"anonymousUser".equals(authentication.getPrincipal())) {
            username = authentication.getName();
        }

        AuditLog log = new AuditLog(operation, entityType, username, LocalDateTime.now(), details);
        auditLogRepository.save(log);
        System.out.println("Audit Logged - User: " + username + ", Op: " + operation + ", Entity: " + entityType + ", Info: " + details);
    }

    public List<AuditLog> getAllLogs() {
        return auditLogRepository.findAllByOrderByTimestampDesc();
    }
}

package com.example.restconf.config;

import com.example.restconf.entity.Role;
import com.example.restconf.entity.User;
import com.example.restconf.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        // Pre-populate users if database is empty
        if (userRepository.count() == 0) {
            System.out.println("Initializing default users (ADMIN, OPERATOR, VIEWER)...");

            User admin = new User("admin", passwordEncoder.encode("adminpassword"), Role.ADMIN);
            User operator = new User("operator", passwordEncoder.encode("operatorpassword"), Role.OPERATOR);
            User viewer = new User("viewer", passwordEncoder.encode("viewerpassword"), Role.VIEWER);

            userRepository.save(admin);
            userRepository.save(operator);
            userRepository.save(viewer);

            System.out.println("Default users created successfully!");
        } else {
            System.out.println("Users already initialized in the database.");
        }
    }
}

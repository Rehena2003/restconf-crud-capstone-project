package com.example.restconf.repository;

import com.example.restconf.entity.NetworkConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NetworkConfigRepository extends JpaRepository<NetworkConfig, String> {
}

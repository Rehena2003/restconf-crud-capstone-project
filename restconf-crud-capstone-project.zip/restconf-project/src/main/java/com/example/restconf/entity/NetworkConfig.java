package com.example.restconf.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "network_configs")
public class NetworkConfig {

    @Id
    private String id;
    private String hostname;
    private String ipAddress;
    private String status; // ACTIVE, INACTIVE

    @jakarta.persistence.ManyToOne
    @jakarta.persistence.JoinColumn(name = "created_by")
    private User createdBy;

    private java.time.LocalDateTime updatedAt;

    public NetworkConfig() {
        this.updatedAt = java.time.LocalDateTime.now();
    }

    public NetworkConfig(String id, String hostname, String ipAddress, String status) {
        this.id = id;
        this.hostname = hostname;
        this.ipAddress = ipAddress;
        this.status = status;
        this.updatedAt = java.time.LocalDateTime.now();
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public java.time.LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(java.time.LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

package com.example.restconf.service;

import com.example.restconf.dto.AuthRequest;
import com.example.restconf.dto.AuthResponse;
import com.example.restconf.entity.User;
import com.example.restconf.repository.UserRepository;
import com.example.restconf.security.JwtUtils;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final UserRepository userRepository;

    public AuthService(AuthenticationManager authenticationManager, JwtUtils jwtUtils, UserRepository userRepository) {
        this.authenticationManager = authenticationManager;
        this.jwtUtils = jwtUtils;
        this.userRepository = userRepository;
    }

    public AuthResponse login(AuthRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        String username = authentication.getName();
        // Extract the prefix-free role name from authority (e.g. ROLE_ADMIN -> ADMIN)
        String authority = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .findFirst()
                .orElse("ROLE_VIEWER");
        
        String roleName = authority.replace("ROLE_", "");

        String token = jwtUtils.generateToken(username, roleName);

        return new AuthResponse(token, username, roleName);
    }
}

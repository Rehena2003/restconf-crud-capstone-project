package com.example.restconf.service;

import com.example.restconf.entity.NetworkConfig;
import com.example.restconf.entity.User;
import com.example.restconf.repository.NetworkConfigRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NetworkConfigService {

    private final NetworkConfigRepository repository;
    private final AuditLogService auditLogService;
    private final com.example.restconf.repository.UserRepository userRepository;

    public NetworkConfigService(NetworkConfigRepository repository, AuditLogService auditLogService, com.example.restconf.repository.UserRepository userRepository) {
        this.repository = repository;
        this.auditLogService = auditLogService;
        this.userRepository = userRepository;
    }

    private User getCurrentUser() {
        org.springframework.security.core.Authentication authentication = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated() && !"anonymousUser".equals(authentication.getPrincipal())) {
            String username = authentication.getName();
            return userRepository.findByUsername(username).orElse(null);
        }
        return null;
    }

    public NetworkConfig create(NetworkConfig config) {
        config.setCreatedBy(getCurrentUser());
        config.setUpdatedAt(java.time.LocalDateTime.now());
        NetworkConfig saved = repository.save(config);
        auditLogService.log("CREATE", "NetworkConfig", "Created network config: ID=" + saved.getId() + ", Hostname=" + saved.getHostname() + ", IP=" + saved.getIpAddress() + ", Status=" + saved.getStatus());
        return saved;
    }

    public Optional<NetworkConfig> get(String id) {
        Optional<NetworkConfig> config = repository.findById(id);
        if (config.isPresent()) {
            auditLogService.log("READ", "NetworkConfig", "Fetched network config with ID=" + id);
        } else {
            auditLogService.log("READ_FAILED", "NetworkConfig", "Attempted to fetch non-existent network config with ID=" + id);
        }
        return config;
    }

    public List<NetworkConfig> getAll() {
        List<NetworkConfig> configs = repository.findAll();
        auditLogService.log("READ", "NetworkConfig", "Fetched all network configurations (Total count: " + configs.size() + ")");
        return configs;
    }

    public NetworkConfig update(String id, NetworkConfig config) {
        config.setId(id); // Ensure correct ID
        
        // Preserve original creator if exists
        repository.findById(id).ifPresent(existing -> {
            config.setCreatedBy(existing.getCreatedBy());
        });
        if (config.getCreatedBy() == null) {
            config.setCreatedBy(getCurrentUser());
        }
        
        config.setUpdatedAt(java.time.LocalDateTime.now());
        NetworkConfig updated = repository.save(config);
        auditLogService.log("UPDATE", "NetworkConfig", "Updated network config: ID=" + id + ", Hostname=" + updated.getHostname() + ", IP=" + updated.getIpAddress() + ", Status=" + updated.getStatus());
        return updated;
    }

    public void delete(String id) {
        repository.deleteById(id);
        auditLogService.log("DELETE", "NetworkConfig", "Deleted network config with ID=" + id);
    }
}

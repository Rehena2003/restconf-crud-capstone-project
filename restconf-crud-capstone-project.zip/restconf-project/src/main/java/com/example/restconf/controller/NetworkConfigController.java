package com.example.restconf.controller;

import com.example.restconf.entity.NetworkConfig;
import com.example.restconf.service.NetworkConfigService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/restconf/config")
public class NetworkConfigController {

    private final NetworkConfigService service;

    public NetworkConfigController(NetworkConfigService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<NetworkConfig> create(@RequestBody NetworkConfig config) {
        NetworkConfig created = service.create(config);
        return ResponseEntity.ok(created);
    }

    @GetMapping
    public ResponseEntity<List<NetworkConfig>> getAll() {
        List<NetworkConfig> list = service.getAll();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<NetworkConfig> get(@PathVariable String id) {
        return service.get(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<NetworkConfig> update(@PathVariable String id, @RequestBody NetworkConfig config) {
        NetworkConfig updated = service.update(id, config);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable String id) {
        service.delete(id);
        return ResponseEntity.ok("Deleted successfully");
    }
}

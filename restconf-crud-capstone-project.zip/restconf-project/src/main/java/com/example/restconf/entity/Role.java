package com.example.restconf.entity;

public enum Role {
    ADMIN,
    OPERATOR,
    VIEWER
}

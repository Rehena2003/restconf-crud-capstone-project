package org.sk.restconfproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestconfProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
